Language: Python

How to run the code: There is 1 IPython notebook called "Backtracking and Heavyball."

These are all set up to be able to run all cells with the points already plugged in.

Contributors: Chad Breece.