Language: Python

How to run the code: There are 3 separate IPython notebooks. 
One is the Exact Steepest Descent Code, 
the second is the Inexact Steepest Descent,
the third is these two methods applied to the Rosenbrock function.
These are all set up to be able to run all cells with the points already plugged in.

Contributors: Chad Breece.