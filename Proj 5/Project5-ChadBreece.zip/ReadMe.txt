Language: Python
How to run: Open ipynb and click Run all. Score is given at the bottom.
Contributors: Chad Breece